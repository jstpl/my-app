
let collection = [
    {
        id: 2,
        title: 'Lorem ipsum',
        content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi pulvinar lorem elit, ac imperdiet dolor\n' +
            'ultrices et. Pellentesque neque est, auctor sit amet blandit a, ornare id sapien. Sed et diam in lorem\n' +
            'porta faucibus. Quisque pulvinar enim nibh. Integer ut mattis nibh, at dictum purus. Sed tincidunt\n' +
            'tellus metus, lacinia semper sem gravida id. In hac habitasse platea dictumst. Integer facilisis est at\n' +
            'lorem hendrerit scelerisque. Sed scelerisque condimentum enim nec placerat. Phasellus id dolor blandit,\n' +
            'tincidunt mi sit amet, pulvinar quam. Maecenas vitae nulla sed purus lobortis ultricies. Morbi arcu\n' +
            'ligula, mattis a pulvinar vitae, aliquam vitae est.'
    },
    {
        id: 1,
        title: 'Integer vestibulum blandit nulla',
        content: 'Integer vestibulum blandit nulla, sed tempus nisl pharetra suscipit. Mauris ut velit eu libero lacinia\n' +
            'posuere. Fusce ex tortor, ultrices eu felis vel, placerat rhoncus sem. Integer eget vehicula magna, sed\n' +
            'semper augue. Pellentesque a diam vel elit viverra tristique vitae eget augue. Donec gravida diam quis\n' +
            'nulla finibus egestas. Nam sapien urna, lobortis at risus vitae, pulvinar tincidunt dolor.'
    },
    {
        id: 3,
        title: 'Etiam nunc urna',
        content: 'Etiam nunc urna, pellentesque id facilisis a, egestas sed odio. Suspendisse potenti. Proin pharetra\n' +
            'convallis urna. Phasellus eget sapien malesuada, tempus sapien at, euismod erat. Aenean gravida dolor in\n' +
            'magna rhoncus lacinia. Etiam cursus est at augue pulvinar, in finibus erat consectetur. Donec dignissim\n' +
            'pharetra libero, eu ultricies odio pellentesque vitae. Morbi sagittis placerat ante, at auctor mauris\n' +
            'egestas sed. Fusce blandit mi a tristique venenatis. Suspendisse potenti. Nam porttitor eleifend leo at\n' +
            'blandit. Quisque vel convallis massa.'
    },
    {
        id: 4,
        title: 'Quisque sed dui velit',
        content: 'Quisque sed dui velit. Duis sodales urna nisi, nec suscipit libero laoreet nec. In scelerisque purus ut\n' +
            'ante finibus porta. Nunc pulvinar fermentum consectetur. Pellentesque sit amet nisl sollicitudin,\n' +
            'feugiat urna at, tempor dui. Aliquam egestas, diam at laoreet dapibus, tortor tortor congue felis, sed\n' +
            'elementum risus metus ac risus. In vitae maximus enim, ut tristique arcu. Aliquam dolor nisl, tempus\n' +
            'eget facilisis non, sollicitudin quis arcu. Fusce hendrerit elit id erat rhoncus varius. Nullam vitae\n' +
            'dui ut arcu congue aliquam. Mauris vitae augue fringilla, laoreet est ut, scelerisque lacus. Morbi vitae\n' +
            'dapibus magna. Duis lacinia orci vitae tortor placerat, ac molestie nibh ultrices. Phasellus molestie\n' +
            'urna turpis, quis lobortis ligula aliquet non. Donec hendrerit accumsan ex. Nunc consectetur nisl velit,\n' +
            'sit amet efficitur ligula auctor vel.'
    },
    {
        id: 5,
        title: 'Donec ac venenatis tellus',
        content: 'Donec ac venenatis tellus, a porta erat. Mauris feugiat, lectus ac cursus pharetra, arcu felis blandit\n' +
            'elit, sed tincidunt lectus augue vel felis. Suspendisse sit amet diam quis metus congue ornare at vel\n' +
            'diam. Nullam vehicula placerat ligula id rhoncus. Duis ac faucibus tortor, a sagittis sem. Suspendisse\n' +
            'ultrices porttitor sem ac feugiat. Vivamus ac finibus risus. Cras id maximus est. Donec luctus tempus\n' +
            'cursus. Phasellus vitae lobortis enim. Curabitur eget suscipit ante, ut varius augue. Donec ac nisl quis\n' +
            'justo laoreet rhoncus. Etiam felis tortor, iaculis ac ultrices a, lacinia id ante. Vestibulum felis\n' +
            'ipsum, bibendum non est et, porta dictum risus. Sed vel tincidunt quam, a accumsan metus.'
    },
];

export default collection;
