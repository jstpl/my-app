import axios from 'axios';
import * as userAction from '../actions/userActions';
import configManager from "../../../packages/configManager/configManager";
import container from "../../../app/config/container";

/**
 * Get all users
 */
export function getUsers() {
    let apiUrl = configManager.get('apiUrl');
    return axios.get(apiUrl + '/users.json')
        .then(response => {
            // let store = container.get('store');
            container.app.store.dispatch(userAction.getUsersSuccess(response.data));
            return response;
        });
}

/**
 * Search users
 */
export function searchUsers(query = '') {
    let apiUrl = configManager.get('apiUrl');
    return axios.get(apiUrl + '/users?q=' + query)
        .then(response => {
            // let store = container.get('store');
            container.app.store.dispatch(userAction.getUsersSuccess(response.data));
            return response;
        });
}

/**
 * Delete a user
 */
export function deleteUser(user) {
    let apiUrl = configManager.get('apiUrl');
    return axios.get(apiUrl + '/users/' + user.id + '.json')
        .then(response => {
            let user = response.data;
            // let store = container.get('store');
            container.app.store.dispatch(userAction.deleteUserSuccess(user));
        });
}

/**
 * getProfile() is much more complex because it has to make
 * three XHR requests to get all the profile info.
 */
export function getProfile(userId) {
    // let store = container.get('store');
    container.app.store.dispatch(userAction.userProfileSuccess({}));
    let apiUrl = configManager.get('apiUrl');
    return axios.get(apiUrl + '/users/' + userId + '.json')
        .then(response => {
            let user = response.data;
            container.app.store.dispatch(userAction.userProfileSuccess(user));
        });
}
